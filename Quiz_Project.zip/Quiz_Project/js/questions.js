
let questions = [
  {
  numb: 1,
  question: "What country has the highest life expectancy?",
  answer: "Hong Kong",
  options: [
    "Korea",
    "Australia",
    "USA",
    "Hong Kong"
  ]
},
  {
  numb: 2,
  question: "What is the capital of France?",
  answer: "Paris",
  options: [
    "Paris",
    "London",
    "Berlin",
    "Madrid"
  ]
},
  {
  numb: 3,
  question: "What is the largest planet in our solar system?",
  answer: "Jupiter",
  options: [
    "Mars",
    "Saturn",
    "Jupiter",
    "Neptune"
  
  ]
},
  {
  numb: 4,
  question: "Which country won the FIFA World Cup in 2018?",
  answer: "France",
  options: [
    "Brazil",
    "Germany",
    "France",
    "Argentina"
  ]
},
  {
  numb: 5,
  question: "What is the chemical symbol for gold?",
  answer: "AU",
  options: [
    "CU",
    "FE",
    "AG",
    "AU"
  ]
},
];